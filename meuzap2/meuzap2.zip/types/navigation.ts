export type RootStackParamList = {
  Login: undefined;
  ChatList: undefined;
  Chat: undefined;
};
